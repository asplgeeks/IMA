<?php

use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception;
// Base files  
require 'php_mailer/Exception.php';
require 'php_mailer/PHPMailer.php';
require 'php_mailer/SMTP.php';
// Base files 
// create object of PHPMailer class with boolean parameter which sets/unsets exception.
// $mail = new PHPMailer(true);      

$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$message = $_POST["message"];

// echo "$name";
// echo "$phone";
// echo "$email";
// echo "$message";

$mail = new PHPMailer(true);                              
try {
    $mail->isSMTP(); // using SMTP protocol                                     
    $mail->Host = 'smtp.gmail.com'; // SMTP host as gmail 
    $mail->SMTPAuth = true;  // enable smtp authentication                             
    $mail->Username = 'postaddamail@gmail.com';  // sender gmail host              
    $mail->Password = 'Postadda@2022#'; // sender gmail host password                          
    $mail->SMTPSecure = 'ssl';  // for encrypted connection                           
    $mail->Port = 465;   // port for SMTP     

    $mail->setfrom('postaddamail@gmail.com', "Enquiry Email"); // sender's email and name
    $mail->addaddress("care@postadda.in", "Receiver");  // receiver's email and name

    $mail->Subject = 'Customer Enquiry';
    $mail->Body    = "<br><br> <hr> <p style='color:#000'> <b>Name: $name<br> <hr> Phone: $phone<br> <hr> Email: $email<br> <hr> Message: $message <hr> </b> </p>";
    
    $mail->IsHTML(true);

    $mail->send();
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        "status" => true,
        "data" => null
    ]);

} catch (Exception $e) { // handle error.

    echo json_encode([
        "status" => false,
        "data" => $mail->ErrorInfo
    ]);
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>




